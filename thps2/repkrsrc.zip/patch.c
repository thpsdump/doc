// patch functions, uses libz stuff, im not going to explain it,
// some things may be broken.. no one uses the patches anyways, so
// I dont care. :-)

#include "1.c"


int create_patch(void);
int apply_patch(char *filename, char *name, int flag);
int check_valid_patch(char *filename);
void get_patch_name(void);

int create_patch(void)
{
 char input[80];
 char *tempfile="thp.tmp";
 char yourname[80];
 char patchname[80];
 FILE *fp, *fp1, *fp2;
 long int offset=0l;
 int a;
 long int size, insize;
 clrscr();
 printf("Enter filename patch will modify in all.pkr\n");
 scanf("%s", input);
 offset=search(input);
 if (!offset) {
    printf("That file is not in all.pkr\n");
    printf("hey a key to return to the main menu");
    a=getche();
    return;
 }
 printf("Enter the filename with the new data\n");
 scanf("%s",yourname);
 fp=fopen(yourname,"rb");
 if (fp==NULL) {
    printf("Error opening your file\n");
    printf("Hit a key to return to the main menu\n");
    a=getche();
    fclose(fp);
    return;
 }
 size=get_file_size_pkr((offset-856)/48);
 insize=get_file_size_normal(yourname);

 if (insize>size) {
    printf("Sorry, your file is too big\n");
    printf("Hit a key to return to the main menu\n");
    a=getche();
    return;
 }


 printf("Enter the name of the patch file to be created\n");
 scanf("%s",patchname);

 fp2=fopen("thp.tmp","wb");
 if (fp2==NULL) {
    printf("error creating tmp file\n");
    exit(-1);
 }

 while (1) {
       a=fgetc(fp);
       if (a==EOF)
          break;
       fputc(a,fp2);
 }
 fclose(fp2);
 fclose(fp);

 fp=fopen(patchname, "wb");
 fprintf(fp, "TH %s %ld\n",input,insize);

 file_compress("thp.tmp", "wb6 ");
 fp1=fopen("thp.tmpgz", "rb");
 if (fp1==NULL) {
    printf("error in .gz");
    exit(-1);
 }

 while (1) {
       a=fgetc(fp1);
       if (a==EOF)
          break;
       fputc(a,fp);

 }

 fclose(fp);
 fclose(fp1);
 unlink("thp.tmpgz");
 printf("\nPatch created succesfully\n");
 printf("Hit a key to return to main menu\n");
 a=getche();
 return;
}




int apply_patch(char *filename, char *name, int flag)
{
  FILE *fp, *fp1;
  long int offset, flen;
  int ch;
  int count=0;
  char *buffer;
  long int size, insize;
  long int intoffset=0l;
  long int tempint;
  double power;
  int i;
  int readin;

  FILE *in, *out;
  offset=search(name);
  fp=fopen(filename, "rb");
  if (fp==NULL) {
     printf("Error in apply_patch\n");
     exit(-1);
  }
  while (1) {
        ch=fgetc(fp);
        if (ch==31)
           break;
        count++;
        }
  fseek(fp, count, SEEK_SET);
  fp1=fopen("thp.gz","wb");
  if (fp1==NULL) {
     printf("error in apply_patch\n");
     exit(-1);
  }

  while (1) {
        ch=fgetc(fp);
        if (ch==EOF)
           break;
        fputc(ch,fp1);

  }
  fclose(fp1);
 file_uncompress("thp.gz");
 size=get_file_size_pkr((offset-856)/48);
 insize=get_file_size_normal("thp");

 //check if thp is small enough to fit
 if (insize>size) {
    printf("Error size mismatch in patch file\n");
    printf("hit a key to return to main menu\n");
    ch=getche();
    return;
 }
 newfilesize(offset, insize);
 tempint=0l;
 in=fopen("all.pkr", "rb");
 if (in==NULL) {
    printf("error opening all.pkr in create_patch\n");
    exit(-1);
 }
 fseek(in, (offset+36), SEEK_SET);

 for (i=0; i<4; i++) {
     readin=fgetc(in);
     tempint=readin*((long) pow(256,i));
     intoffset+=tempint;
 }
 fclose(in);
 in=fopen("all.pkr","ab+");
 fp=fopen("thp","rb");
 fseek(in, intoffset, SEEK_SET);
 while (1) {
       ch=fgetc(fp);
       if (ch==EOF)
          break;
       fputc(ch, in);
 }
 fclose(in);
 fclose(fp);


 if (flag==1) {
  printf("\nPatch applied successfully\n");
  printf("Hit a key to return to main menu\n");
  ch=getche();
 }
 unlink("thp");





return;
}

int check_valid_patch(char *filename)
{
 FILE *fp;
 char data[2];
 char name[80];
 long int size;
 long int b;
 int c;
 fp=fopen(filename, "rt");
 if (fp==NULL) {
    printf("file does not exist\n");
    exit(-1);
 }
 fscanf(fp, "%s %s %ld",data, name, &size);

 fclose(fp);
 if (strcmp(data,"TH")) {
  printf("TH\n");
  c=getche();
  return(0);
 }

 b=search(name);
 if (!b) {
 printf("name");
 c=getche();
    return(0);
 }
return(1);
}


void get_patch_name(void)
{
 char data[2];
 char name[80];
 long int size;
 char filename[80];
 FILE *fp;
 int a;
 clrscr();
 printf("Enter the patch file name\n");
 scanf("%s",filename);
 fp=fopen(filename, "rb");
 if (fp==NULL) {
    printf("Error opening patch file\n");
    printf("Hit a key to return to main menu\n");
    a=getche();
    return;
 }

 fclose(fp);
 if (!check_valid_patch(filename)) {
    printf("NOT A valid patch file\n");
    printf("Hit a key to return to the main menu\n");
    a=getche();
    return;
 }
 fp=fopen(filename, "r");
 fscanf(fp, "%s %s %ld",data, name, &size);
 fclose(fp);
 apply_patch(filename, name,1);


 return;
}
