Source code for my repkr.
I apologize if some of the indentation is off.. blame rhide. :-)

Will not compile unless you have libz installed.

Compile with gcc tony.c -o repkr.exe -lz
Will get some warnings, just ignore them. :-)

Forward any questions to thps2pkr@hotmail.com


By using/reading this source code, you agree not to hold responsible
the writer of ANYTHING the program does.  Use at your own risk.
