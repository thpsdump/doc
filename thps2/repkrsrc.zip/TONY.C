/* tony.c - the main program with some other functions thrown in
   I tend to use weird variable names, sorry about that. :-(
   I will also sometimes declare variables, and not even use them. :-(
   Hopefully, this is readable, and somewhat understandable.. :-)
   Patch code still aint perfect, sometimes causes core dumps.
*/

#include "stdio.h"
#include "fcntl.h"
#include "sys\stat.h"
#include "io.h"
#include "math.h"
#include "file.h"
#include "patch.c"
#include "zlib.h"


#ifndef O_BINARY
#define O_BINARY 0
#endif
#define ME 1   // if this is set to 0 disclaimers will pop up.

// function prototypes

void areyousure(void);
void showdisclamer(void);
int menu(void);
void centermsg(char *msg);
void rightmsg(char *msg);
void banner(void);
void limitations(void);
void import(void);
void export(void);
long int filesize(long int off);


void banner(void)
{
  int i;
  for (i=0; i<80; i++) printf("*");
  return;
}

void rightmsg(char *msg)
{
  int i,j,k,l,len;
  len=strlen(msg);
  printf("* ");
  printf("%s",msg);
  l=77-strlen(msg);
  for (i=0; i<l; i++) printf(" ");
  printf("*");
  return;
}

void centermsg(char *msg)
{
  int len,l,j,k;
  len=strlen(msg);
  printf("*");
  l=(78-len)/2+1;
  for (j=0; j<l; j++) printf(" ");
  printf("%s",msg);
  if (len%2==0) k=l-2;
  else k=l-1;
  for (j=0; j<k; j++) printf(" ");
  printf("*");
  return;
}


int menu(void)
{
  char choice;
  clrscr();
  banner();
  centermsg("A Lame RePKR Program for Tony Hawk 2");
  centermsg("Version 0.3�");
  centermsg("Written by M. Parsons (thps2pkr@hotmail.com)");
  centermsg("(c) 2000");
  banner();
  printf("\n\n\n");
  banner();
  centermsg("Menu options");
  centermsg("");
  centermsg("");
  rightmsg("1.  Limitations of program (PLEASE READ THIS)");
  rightmsg("2.  Extract a file from all.pkr");
  rightmsg("3.  Import a file into all.pkr");
  rightmsg("4.  Create patch");
  rightmsg("5.  Apply patch");
  rightmsg("6.  Quit");
  centermsg("");
  banner();
  printf("\n\n");
  printf("Please enter your choice");
  choice=getch();
  while ((choice<49) || (choice>54))
   choice=getch();

  return(choice);
}

// this fxn aint even used

void showdisclamer(void)
{
 int i;
 clrscr();
 banner();
 printf("WARNING! WARNING! WARNING!\n");
 printf("This file makes changes to the all.pkr file, which MAY result in a corrupted\ndata file.  Use at your own risk.\n");
 banner();
 printf("\n");
 return;
 }

// same here, not used

void areyousure(void)
{
  char ch;
  printf("Please make a backup of the all.pkr file before continuing.\n");
  printf("Have you made a backup of this file?\n");
  ch=getch();
  if (ch!='Y' && ch!='y') {
     printf("Then please make a backup before continuing\n");
     exit(-1);
  }
  printf("Are you really sure you wish to continue?\n");
  ch=getch();
  if (ch!='Y' && ch!='y') {
     printf("Exiting....\n");
     exit(-1);
  }
  return;
}

void limitations(void)
{
 clrscr();
 printf("Read the pkr.txt file.");
 exit(-1);
}

// Function to import a file into all.pkr

void import(void)
{
 FILE *in, *out;
 char input[34];
 char input2[80];
 long int offset=0l;
 long int size=0l;
 int readin;
 long int intoffset=0l;
 long int filelength=0l;
 long int insize=0l;
 int i=0;
 long int newsize=0l;
 int k;
 long int tempint;
 double power;

 clrscr();
 printf("Which file in all.pkr do you wish to overwrite? <q to quit>\n");
 scanf("%s",input);
 while (!offset) {
  if (!strcmp(input, "q"))
   return;
  offset=search(input);  // offset=position of filename in all.pkr
  if (offset)
     break;
  clrscr();
  printf("FILE NOT FOUND\n");
  printf("Which file in all.pkr do you wish to overwrite? <q to quit>\n");
  scanf("%s",input);
  }
  clrscr();
  printf("Which file on your hard drive contains the new data?\n");
  scanf("%s",input2);
  out=fopen(input2,"rb");
  if (out==NULL) {
     printf("Error opening your file, hit a key to return to main menu...\n");
     i=getche();
     return;
  }

 /* weird math here, get_file_size_pkr should be rewritten, but im lazy */
 size=get_file_size_pkr((offset-856)/48);
 tempint=0l;
 tempint=0l;
 insize=get_file_size_normal(input2);
 // lame math here too
 newsize=pkrfilesize((offset-856)/48);
/* if (insize>size) {
    printf("Sorry, this current version only allows for smaller file sizes\n");
    printf("Hit a key to return to the main menu..\n");
    fclose(in);
    fclose(out);
    i=getche();
    return;
 }*/
 newfilesize(offset, insize);
 tempint=0l;
 in=fopen("all.pkr","rb");
 if (in==NULL) {
    printf("error\n");
    exit(-1);
 }
 // 36 bytes after the file name is the file offset, so calculate it
 fseek(in, (offset+36), SEEK_SET);
 for (i=0; i<4; i++) {
     readin=fgetc(in);
     tempint=readin*((long) pow(256,i));
     intoffset+=tempint;
 }
 fclose(in);
 fclose(out);

 // this is the time consuming copy if size of import file is bigger
 // could be optimized better, does 1 char at a time, would be
 // better to use a buffer.
 // could also be copied to its own functions, but im lazy :-)

 if ((insize>size) && (insize>newsize))
 {
  printf("Copying lots of data, go have a coffee break\n");
  in=fopen("all.pkr", "rb");
  out=fopen("a.tmp", "wb");  // this is the temp file
  fseek(in, intoffset+size, SEEK_SET);
  while (1) {
   k=fgetc(in);
   if (k==EOF) break;
   fputc(k, out);
  }
  fclose(in);
  fclose(out);
  in=fopen("all.pkr","ab+");
  out=fopen(input2,"rb");
  fseek(in, intoffset, SEEK_SET);
  while (1) {
   k=fgetc(out);
   if (k==EOF)
    break;
   fputc(k,in);
  }
  fclose(in);
  fclose(out);
  in=fopen("all.pkr", "ab");
  out=fopen("a.tmp", "rb");
  fseek(in, intoffset+insize, SEEK_SET);
  while (1) {
   k=fgetc(out);
   if (k==EOF) break;
   fputc(k,in);
  }
  fclose(in);
  fclose(out);
  new_file_pointer(offset, insize-size); // change all file pointers
  unlink("a.tmp");   // erase tmp file
 }

// else file size is smaller, so just overwrite data

 else {
  in=fopen("all.pkr","ab+");
  out=fopen(input2,"rb");
  fseek(in, intoffset, SEEK_SET);
  while (1) {
   k=fgetc(out);
   if (k==EOF)
    break;
   fputc(k,in);
  }
 }
 printf("Importing successful\n");
 printf("\nHit a key to return to main menu\n");
 i=getche();
 return;
}

// fxn to extract a file from all.pkr

void extract(void)
{
 FILE *in, *out;
 char input[34];
 long int offset=0l;
 long int size=0l;
 int readin;
 long int intoffset=0l;
 long int filelength=0l;
 int i=0;
 long int tempint;
 double power;

 clrscr();
 printf("Enter the filename you wish to extract <q to return to main menu>\n");
 printf(">");
 scanf("%s",input);
 printf("%s",input);
 while (!offset) {
  if (!strcmp(input, "q"))
   return;
  offset=search(input);
 if (offset)
   break;
  clrscr();
  printf("FILE NAME NOT FOUND, TRY AGAIN\n");
  printf("Enter the filename you wish to extract <q to return to main menu>\n");
  printf(">");
  scanf("%s",input);
  }
 printf("File name matched! Extracting %s into current dir",input);
 size=filesize(offset);
 in=fopen("all.pkr","rb");
 if (in==NULL) {
    printf("error\n");
    exit(-1);
    }
 out=fopen(input, "wb");
 if (out==NULL) {
    printf("errororor\n");
    exit(-1);
 }
 fseek(in, size, SEEK_SET);
 for (i=0; i<4; i++) {
     readin=fgetc(in);
     tempint=readin*((long) pow(256,i));
     filelength+=tempint;
 }
 tempint=0l;
 fseek(in, (offset+36), SEEK_SET);
 for (i=0; i<4; i++) {
     readin=fgetc(in);
     tempint=readin*((long) pow(256,i));
     intoffset+=tempint;
 }

 fseek(in, intoffset, SEEK_SET);
 for (i=0; i<filelength; i++) {
     readin=fgetc(in);
     fputc(readin, out);
 }
 fclose(out);
 fclose(in);
 printf("\npausing...hit a key to continue\n");
 readin=getche();
 return;
}


// Im assuming filesize offset is 40 bytes after filename, this function
// is stupid, and should be replaced.

long int filesize(long int off)
{
  return (off+40);
}

int main(int argc, char *argv[])
{
  int choice=0;
  FILE *fap;
  char a[2];
  char b[80];
  long int c;
  int i,test;
#ifndef ME
  showdisclamer();
  areyousure();
#endif
 if (argc==1) {
  choice=menu();
  while (choice!=54)
  {
   switch (choice)
   {
    case 49:
         limitations();
         choice=0;
         break;
    case 50:
         extract();
         choice=0;
         break;
    case 51:
         import();
         choice=0;
         break;
    case 52:
         create_patch();
         choice=0;
         break;
    case 53:
         get_patch_name();
         choice=0;
         break;
    default:
         choice=menu();
    }
   }
  }
 else if (argc==2) {
      argv++;
      if (check_valid_patch(*argv))
        {
        fap=fopen(*argv, "r");
        fscanf(fap, "%s %s %ld", a, b ,c);
        fclose(fap);
        apply_patch(*argv, b,0);
        printf("Patch applied\n");
        }
      else
        printf("error applying patch\n");
      }
   exit(-1);
}
