// Misc. file functions

void newfilesize(int filenum, long int newsize);
long int get_file_size_normal(char *str);
long int get_file_size_pkr(long int offset);
long int search(char *string);
void new_file_pointer(long int offset, long int insize);
long int pkrfilesize(long int offset);


// gets the filesize of the file starting at offset

long int pkrfilesize(long int offset)
{
 FILE *fp;
 long int c;
 int b,a;
 long int tempa=0, tempb=0;
 fp=fopen("all.pkr","rb");
 if (fp==NULL) {
    printf("error\n");
    exit(-1);
 }
 // printf("offset is %ld\n",offset);
 fseek(fp, 896+(48*offset), SEEK_SET);
 for (a=0; a<4; a++) {
     b=fgetc(fp);
     tempa=b*((long) pow(256,a));
     tempb+=tempa;
 }
 fclose(fp);
 return tempb;
}

// when importing a larger file into all.pkr, file offset pointers have to be
// changed for all files coming after that file.  This function does that.

void new_file_pointer(long int offset, long int insize)
{
 FILE *fp;
 char ch;
 int i;
 long int intoffset=0l;
 long int tempint=0;
 int readin;
 double power;
 long int e=0, f=0, g=0, h;
 int q[4];
 offset+=36;
 offset+=48;
 while (offset<=181852) {
   fp=fopen("all.pkr","rb");
   if (fp==NULL) {
      printf("error reading all.pkr in new_file_pointer\n");
      exit(-1);
   }
   fseek(fp, offset, SEEK_SET);
   for (i=0; i<4; i++) {
       readin=fgetc(fp);
       tempint=readin*((long) pow(256,i));
       intoffset+=tempint;
   }
   intoffset=intoffset+insize;
   fclose(fp);
   h=intoffset;
   fp=fopen("all.pkr", "ab");
   if (fp==NULL) {
      printf("asdlfkjasldkfjasldfkj");
      exit(-1);
   }
   fseek(fp, offset, SEEK_SET);
   for (e=3; e>=0; e--) {
       f=h/((long) pow(256,e));
       h-=f*((long) pow(256,e));
       q[e]=f;
   }
   for (e=0; e<4; e++) {
       fputc(q[e], fp);
   }
   fclose(fp);
   intoffset=0l;
   tempint=0l;
   offset+=48;
 }
}

// searches through all.pkr for the file passed via string
// new: will prompt user if the filename is mentioned more than once
// in all.pkr. Returns file location or 0 if none found/error.

long int search(char *string)
{
 FILE *in;
 int ch;
 int replace;
 int j,i,l;
 int place[10];
 int matches=0;
 char blah[34]="";
 char blank[34]="                                 ";
 in=fopen("all.pkr","rb");
 if (in==NULL) {
    printf("error opening file\n");
    exit(-1);
 }
 strupr(string);
 l=strlen(string);
 for (i=0; i<3771; i++) {
     fseek(in, (856+(i*48)), SEEK_SET);
     fread(blah, sizeof(char), 32, in);
     if (!(strcmp(blah,string))) {
         place[matches]=i;
         matches++;
         }
  }
 if (matches==1)
   return(856+place[0]*48);
 if (matches>=2) {
   printf("\nTwo or more files of that name are in all.pkr\n");
   printf("Do you wish to replace: \n");
   for (j=0; j<matches; j++) {
       printf("%d.  File at offset %ld\n", j, 856+place[j]*48);
   }
   scanf("%d",&replace);
   if ((replace<0) || (replace>matches-1)) {
      fclose(in);
      return (0);
   }
   fclose(in);
   return(856+place[replace]*48);
   }
 fclose(in);
 return (0);
}

// get file size from the file.siz file.. this should get replaced.
// was a good idea when only smaller files were allowed, not that great
// now since larger files are allowed

long int get_file_size_pkr(long int offset)
{
 long int c;
 int b,a;
 long int tempa=0, tempb=0;
 FILE *fs;
 fs=fopen("file.siz","rb");
 if (fs==NULL) {
    printf("Error opening file.siz in get_file_size_pkr\n");
    exit(-1);
 }
 fseek(fs, offset*4, SEEK_SET);
 for (a=0; a<4; a++) {
     b=fgetc(fs);
     tempa=b*((long) pow(256,a));
     tempb+=tempa;
 }
 fclose(fs);
return tempb;
}

// returns file length of file passed in str

long int get_file_size_normal(char *str)
{
 FILE *in;
 long int flen;
 in=fopen(str, "rb");
 if (in==NULL) {
    printf("Error in get_file_size_normal\n");
    exit(-1);
 }
 if(fseek(in, 0L, SEEK_END)) {
              printf("error in fseeking in get_file_size_normal\n");
              exit(-1);
 }
 flen=ftell(in);
 fclose(in);
 return (flen);
}

// changes the filesize bytes in all.pkr to match the new size of the
// imported file

void newfilesize(int filenum, long int newsize)
{
 FILE *file;
 long int e=0, f=0, g=0, h;
 int q[4];
 h=newsize;
 file=fopen("all.pkr","ab");
 if (file==NULL) {
   printf("error opening all.pkr in newfilesize\n");
   exit(-1);
 }
 fseek(file, (filenum+40), SEEK_SET);
 for (e=3; e>=0; e--) {
    f=h/((long) pow(256,e));
    h-=f*((long) pow(256,e));
    q[e]=f;
 }
 for (e=0; e<4; e++) {
  fputc(q[e],file);
 }
 for (e=0; e<4; e++) {
  fputc(q[e],file);
 }
 fclose(file);
 return;
}
