#if 0
#define PRINTF(x) printf x
#else
#define PRINTF(x) 
#endif
#define ERROR(x) printf x
#define xPRINTF(x) 

#define BASE_priority  32

#define OLDLIB 0
#define TRANS_CH  0

