#include <core/defines.h>
#include <gel/object.h>
#include <gel/ObjPtr.h>

namespace Obj
{




}
