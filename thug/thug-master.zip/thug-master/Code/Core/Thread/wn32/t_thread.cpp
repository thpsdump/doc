/*******************************************************************
*
*    DESCRIPTION: t_target.h
*
*    AUTHOR:	JAB
*
*    HISTORY:
*
*    DATE:9/5/2000
*

		This is a dummy file, because its in the NGPS version
		it has to be here too.

*******************************************************************/

/** include files **/

/** local definitions **/

/* default settings */

/** external functions **/

/** external data **/

/** internal functions **/

/** public data **/

/** private data **/

/** public functions **/

/** private functions **/

