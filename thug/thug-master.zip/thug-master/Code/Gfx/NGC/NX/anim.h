#ifndef __ANIM_H
#define __ANIM_H

namespace NxNgc
{

//DWORD	GetVertexShader( bool vertex_colors );
//void	CreateWeightedMeshVertexShaders( void );
//void	setup_weighted_mesh_vertex_shader( void *p_root_matrix, void *p_bone_matrices, int num_bone_matrices );
//void	shutdown_weighted_mesh_vertex_shader( void );


} // namespace NxNgc

#endif // __ANIM_H

