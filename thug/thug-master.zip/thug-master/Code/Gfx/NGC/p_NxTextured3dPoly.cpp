#include 	"Gfx/ngc/p_NxTextured3dPoly.h"

namespace NxNgc
{

////////////////////////////////////////////////////////////////////////////////////
// Here's a machine specific implementation of CTextured3dPoly

CNgcTextured3dPoly::CNgcTextured3dPoly()
{
}

CNgcTextured3dPoly::~CNgcTextured3dPoly()
{
}

void CNgcTextured3dPoly::plat_set_texture(uint32 texture_checksum)
{
}	

void CNgcTextured3dPoly::plat_render()
{
}

} // Namespace NxNgc  			
				
				
